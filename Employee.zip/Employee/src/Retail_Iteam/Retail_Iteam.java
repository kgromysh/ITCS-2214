package Retail_Iteam;

/**
 * Created by Kristina on 5/25/2016.
 */
public class Retail_Iteam
{
    private String description;//Holds a brief description of the Iteam.
    private int unitsOnHand;// Holds the number of units currently in the inventory
    private double price;//Iteam's retail price

    private  double total = 0;
    private double tax = .7;

    //constructor associates the information from driver to specific object contact
    public Retail_Iteam(String description, int unitsOnHand, double price)
    {
      this.description=description;
      this.unitsOnHand=unitsOnHand;
      this.price=price;
    }



    public void setDescription(String description)
    {
       this.description = description;
    }

    public void setUnitsOnHand( int unitsOnHand)
    {
      this.unitsOnHand =unitsOnHand;
    }

    public void setPrice(double price)
    {
      this.price = price;
    }

    public String getDescription()
    {
        return description;
    }

    public int  getUnitsOnHand()
    {
        return unitsOnHand;

    }
    public double getPrice()
    {
        return price;
    }

    public  double CalcPrice()
    {

        total = tax * price;
        return  total;
    }
}
