package Retail_Iteam;

/**
 * Created by Kristina on 5/25/2016.
 */
public class Retail_Iteam_Driver
{
  public static void main(String[] args)
  {
      Retail_Iteam  retailObject1 = new Retail_Iteam("Jacket", 12  , 59.95); // object created from Retail_Iteam class
      Retail_Iteam  retailObject2 = new Retail_Iteam("Designer Jeans", 40  , 34.95);
      Retail_Iteam  retailObject3 = new Retail_Iteam("Jacket", 12  , 24.95); // object created from Retail_Iteam class

      System.out.println();
      System.out.println(retailObject1.getDescription()+
                   " " + retailObject1.getUnitsOnHand()+
                   " " + retailObject1.getPrice());
      System.out.println("The calculated price with tax is: " + retailObject1.CalcPrice());
      System.out.println(retailObject2.getDescription()+
              " " + retailObject2.getUnitsOnHand()+
              " " + retailObject2.getPrice());

      System.out.println(retailObject3.getDescription()+
              " " + retailObject3.getUnitsOnHand()+
              " " + retailObject3.getPrice());


  }
}
