/**
 * Created by Kristina on 5/25/2016.
 */
public class EmployeeRun
{
    public static void main(String[] args)
    {
        Employee employeeObject1 = new Employee("Susan", 47899, "Accounting", "Vice President");
        Employee employeeObject2 = new Employee("Mark", 39119, "IT", "Programmer");
        Employee employeeObject3 = new Employee("Joy", 81774, "Manufacturing", "Engineer");

        //the purpose of the object
        //is to make the connection to the class Employee.

        System.out.println(employeeObject1.getName() + " "
                + employeeObject1.getIdNumber() + " "
                + employeeObject1.getDepartment() + " "
                + employeeObject1.getPosition());
        System.out.println(employeeObject2.getName() + " "
                + employeeObject2.getIdNumber() + " "
                + employeeObject2.getDepartment() + " "
                + employeeObject2.getPosition());
        System.out.print(employeeObject3.getName() + " "
                + employeeObject3.getIdNumber() + " "
                + employeeObject3.getDepartment() + " "
                + employeeObject3.getPosition());
    }
}
