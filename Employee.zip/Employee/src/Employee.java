/**
 * Created by Kristina on 5/25/2016.
 */
public class Employee
{   //Fields
    private String name;//Holds the employee's name
    private int idNumber;//Holds the employee's id number
    private String department;//Holds the employee's department
    private String position;//Holds the employee's job title
    //constructor
    public Employee(String name, int idNumber, String department, String postion )
    {
      this.name=name;
      this.idNumber=idNumber;
      this.department=department;
      this.position=postion;
    }
   public void setName(String name)//seter's require input parameter type
   {
    this.name=name;

   }
    public void setIdNumber(int idNumber)//seter's require input parameter type
    {
        this.idNumber=idNumber;

    }
    public void setDepartment(String department)//seter's require input parameter type
    {
        this.department=department;

    }
    public void setPostion(String position)//seter's require input parameter type
    {
        this.position=position;

    }

    public String getName()
    {
     return name;
    }

    public int getIdNumber()
    {
        return idNumber;
    }

    public String getDepartment()
    {
        return department;
    }

    public String getPosition()
    {
        return position;
    }

}
