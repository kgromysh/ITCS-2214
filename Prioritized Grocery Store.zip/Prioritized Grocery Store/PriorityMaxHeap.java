/**
 * PriorityMaxHeap sorts the added PriorityCustomers based on their priority values.
 * 
 * 
 */

public class PriorityMaxHeap {
   private PriorityCustomer [] heap;
   private int size;
   private int removed;
   
   /**
    * Default Constructor sets all values to zero and initializes an array representation of the heap
    * utilizing 100 slots.
    */
   public PriorityMaxHeap()
   {
      heap = new PriorityCustomer[100];
      size = 0;
      removed = 0;
   }

   /**
    * This method takes a PriorityCustomer and adds it to the heap, swapping by priority as needed.
    * Once addition is complete the size of the heap is increased by one.
    * 
    * @param PriorityCustomer pc - takes a PriorityCustomer object to be added to the heap.
    */
   public void add (PriorityCustomer pc)
   {
      //Select the next available element and add PriorityCustomer
      int index = size + 1;
      heap[index] = pc;
      
      //While node has parents            
      while ( index > 1 ) 
      {
         //get the parent index
         int parentIndex = index / 2;
         
         //If the parent is not the root, and the child has a higher priority
         if(parentIndex!= 1 && heap[parentIndex].getPriority() < pc.getPriority() ) 
         {  
            //swap their positions in the heap
            heap[index] = heap[parentIndex];
            heap[parentIndex] = pc;     
            
            index = parentIndex;
         }
         //or exit the loop
         else{       
            break;         
         }
      }
      
      //Increase heap size
      size ++;
   }
   
   /**
    * This method removes the rootValue of the heap and swaps subsequent high priority
    * customers to the top as appropriate.
    */
   public void remove () {
      //Move the last value in the heap to the root and clear the last index
      PriorityCustomer last = heap[size];
      heap[1] = last;
      heap[size] = null;
      
      //Beginning from the root
      int index = 1; 
      
      //While there are other children in the heap
      while(index * 2 < size)
      {
         //Set indices for children
         int leftIndex = index * 2;
         int rightIndex = leftIndex + 1;
         
         //Set references for children (other customers in line)
         PriorityCustomer leftValue = heap[leftIndex];
         PriorityCustomer rightValue = null;
         
         //Assign reference to the right child if there is one
         if(rightIndex < size)
         {
            rightValue = heap[rightIndex];
         }
         
         //Set reference for the max priority customer and it's index
         PriorityCustomer maxChild;
         int maxIndex;          
         
         //If there is a right child and it had a priority greater than or equal to the left child
         if(rightValue!= null && leftValue.getPriority() <= rightValue.getPriority() )
         {
            //Assign it as the maxChild 
            maxChild = rightValue;
            maxIndex = rightIndex;
         }
         else{
            //other wise assign the left child as the maxChild 
            maxChild = leftValue;
            maxIndex = leftIndex;         
         }
         
         //If the maxChild has a higher priority than the root, swap them.
         if(last.getPriority() < maxChild.getPriority())
         {
            heap[index] = maxChild;
            heap[maxIndex] = last;
            index = maxIndex;
         }
         else
         {
            //or exit the loop 
            break;
         }
      }
      
      //Decrease heap size, increase removed count
      size --;
      removed ++;
   }
   
   /***
    * Returns the customer at the front of the line, or top of the heap.
    */
   public PriorityCustomer getFirst( )
   {
       return heap[1];
   }
   
   /**
    * Returns the size of the heap.
    * 
    * @return int size
    */
   public int getSize( )
   {
       return size;
   }
   
   /**
    * Checks to see if the heap is empty
    * 
    * @return boolean - Returns true is the size is 0.
    */
   public boolean isEmpty( )
   {
       return size == 0;
   }
   
   /**
    * Returns a count of the number of customers removed from the heap.
    * 
    * @return int removed
    */
   public int getRemoved ( )
   {
       return removed;
   }
}