/**
 * CheckOut simulates service at a store register over a 60 minute period based
 * on priority of service. It utilizes a Max Heap and the Customer Class.
 * 
 * 
 */

import java.util.*;

public class PriorityCheckout
{
    public static void main (String [] args)
    {
        int maxLength = 0;
        PriorityMaxHeap line = new PriorityMaxHeap ( );
        Random rand = new Random ( );
        
        System.out.println("                            10 ITEMS OR LESS");
        
        for (int i = 0; i < 60; i ++)
        {
            System.out.println(i+1 + "------------------------------------------------------------------");
            
            //25% Chance of creating a new customer, create new customer if a 1 is generated 
            if ((rand.nextInt(4)+1) == 1)
            {
                line.add(new PriorityCustomer( ));
                
                //Compare for maximum line length at any given iteration
                if (line.getSize( ) > maxLength)
                    maxLength = line.getSize( );
                    
                //Notify of customer added and new queue length    
                System.out.println("\tNew customer added! Queue length is now " + line.getSize( ) + ".\n");
            }
            
            //If the line is not empty
            if (!line.isEmpty())
            {              
                //and the customer has not been fully serviced
                 if (line.getFirst( ).getServiceTime( ) != 0)
                 {
                     //print the service time of customer at the top of the heap, then decrease service time by one  
                     System.out.println("\tCurrently servicing customer. Time remaining is " + line.getFirst( ).getServiceTime( ) + " minute(s).");
                     line.getFirst( ).decServiceTime( );
                 }
                 //and the customer has been fully serviced
                 else
                 {  
                     //remove from line and print count of fully services customers
                     line.remove( );
                     System.out.println("\tCustomer serviced and removed from the queue.\n\t" + line.getRemoved( ) + " Happy customer(s).\n\tQueue length is now " + line.getSize( ) + ".\n\t");
                     
                     //Get next person in line, if one exists, and decrease service time by one.
                     if (line.getFirst( ) != null)
                     {
                         System.out.println("\tNow serving next customer. Time remaining is " + line.getFirst( ).getServiceTime( ) + " minutes.");
                         line.getFirst( ).decServiceTime( );
                     }

                 }
            }   
            //If the line is empty, print that the line is open
            else
            {
                System.out.println("\tLane is open.");
            }
        }
        
        System.out.println("\n====================================================================");
        System.out.println("        TOTAL CUSTOMERS SERVICED: \t" + line.getRemoved( ));
        System.out.println("        MAXIMUM LINE LENGTH: \t\t" + maxLength);
    }
}

